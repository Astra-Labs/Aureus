/// {@category Objects}
/// {@image <image alt='' src=''>}